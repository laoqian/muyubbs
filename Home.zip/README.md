# muyubbs


这是一个基于thinphp 3.2的bbs系统，包含前台和后台
